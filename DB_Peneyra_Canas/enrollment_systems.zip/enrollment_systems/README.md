# Student Enrollment System

## Project Overview
The Student Enrollment System is a web application designed to manage courses, students, enrollments, and grades for educational institutions. This project utilizes a MySQL database for data management and PHP for server-side scripting, with a user-friendly front end built using HTML and CSS.

## Features
- Manage student information, including enrollment and grades.
- Manage course details and instructor information.
- Enroll students in courses with capacity checks.
- Generate reports on student grades and course enrollments.
- User-friendly interface for navigating between different sections of the system.

## Database Schema
The database consists of the following tables:
- **Students**: Stores student information with unique email constraints.
- **Courses**: Contains course details and related information.
- **Enrollments**: Links students to courses, including grade information and enrollment dates.
- **Instructors**: Holds instructor details and their associated courses.

## Setup Instructions
1. **Database Setup**:
   - Import the `database.sql` file located in the `src/db` directory into your MySQL database to create the necessary tables and insert sample data.

2. **Configuration**:
   - Update the `config.php` file in the `src/php` directory with your database connection settings.

3. **Running the Application**:
   - Place the project files on a server with PHP and MySQL support.
   - Access the application through the `index.html` file located in the `src/public` directory.

## Usage Guidelines
- Navigate through the application using the main menu on the landing page.
- View and manage students, courses, enrollments, and instructors through their respective pages.
- Use the enrollment page to enroll students in courses and manage their records.

## Technologies Used
- **Frontend**: HTML, CSS
- **Backend**: PHP
- **Database**: MySQL

## Future Enhancements
- Implement user authentication for secure access.
- Add advanced reporting features for better data analysis.
- Enhance the user interface for improved user experience.