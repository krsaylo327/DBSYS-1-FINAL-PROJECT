<?php
// This file contains utility functions used across the PHP scripts

// Function to sanitize user input
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Function to connect to the database
function dbConnect() {
    $config = include('config.php');
    $conn = new mysqli($config['host'], $config['username'], $config['password'], $config['database']);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Function to execute a query and return results
function executeQuery($query) {
    $conn = dbConnect();
    $result = $conn->query($query);
    $conn->close();
    return $result;
}

// Function to check if a student exists by email
function studentExists($email) {
    $email = sanitizeInput($email);
    $query = "SELECT * FROM Students WHERE email = '$email'";
    $result = executeQuery($query);
    return $result->num_rows > 0;
}

// Function to validate grade input
function validateGrade($grade) {
    return is_numeric($grade) && $grade >= 0 && $grade <= 100;
}
?>