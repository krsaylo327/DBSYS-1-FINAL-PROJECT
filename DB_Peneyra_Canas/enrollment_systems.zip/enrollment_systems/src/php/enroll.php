<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course_id'];
    $enrollment_date = date('Y-m-d');

    // Check course capacity
    $capacity_check_query = "SELECT capacity, (SELECT COUNT(*) FROM enrollments WHERE course_id = ?) AS enrolled_count FROM courses WHERE id = ?";
    $stmt = $conn->prepare($capacity_check_query);
    $stmt->bind_param("ii", $course_id, $course_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $course = $result->fetch_assoc();

    if ($course) {
        if ($course['enrolled_count'] < $course['capacity']) {
            // Insert enrollment
            $enroll_query = "INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($enroll_query);
            $stmt->bind_param("iis", $student_id, $course_id, $enrollment_date);

            if ($stmt->execute()) {
                echo "Enrollment successful!";
            } else {
                echo "Error enrolling student: " . $stmt->error;
            }
        } else {
            echo "Course is full. Enrollment failed.";
        }
    } else {
        echo "Course not found.";
    }
}
?>