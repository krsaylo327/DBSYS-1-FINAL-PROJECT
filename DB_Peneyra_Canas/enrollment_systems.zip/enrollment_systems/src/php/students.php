<?php
require_once 'config.php';

// Function to retrieve all students
function getAllStudents($conn) {
    $sql = "SELECT * FROM Students";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return [];
    }
}

// Function to retrieve a student by ID
function getStudentById($conn, $studentId) {
    $sql = "SELECT * FROM Students WHERE student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

// Fetch all students
$students = getAllStudents($conn);

// Close the database connection
$conn->close();
?>