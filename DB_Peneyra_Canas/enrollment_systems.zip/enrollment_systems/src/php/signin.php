<?php
// signin.php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    if (empty($email)) {
        $error = 'Email is required.';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM Students WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            // Redirect to home page after successful sign in
            header('Location: ../public/index.html');
            exit();
        } else {
            $error = 'No account found with that email.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign In</title>
    <link rel="stylesheet" href="../public/styles.css">
</head>
<body>
    <h2>Sign In</h2>
    <?php if (!empty($error)) echo '<p style="color:red;">' . $error . '</p>'; ?>
    <form method="post" action="signin.php">
        <label>Email: <input type="email" name="email" required></label><br>
        <button type="submit">Sign In</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a></p>
</body>
</html>
