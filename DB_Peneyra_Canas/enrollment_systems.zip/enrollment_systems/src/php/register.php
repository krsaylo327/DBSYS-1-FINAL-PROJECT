<?php
// register.php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $email = $_POST['email'] ?? '';

    if (empty($firstName) || empty($lastName) || empty($email)) {
        $error = 'All fields are required.';
    } else {
        try {
            $stmt = $pdo->prepare('INSERT INTO Students (first_name, last_name, email) VALUES (?, ?, ?)');
            $stmt->execute([$firstName, $lastName, $email]);
            // Redirect to sign in page after successful registration
            header('Location: ../public/signin.html');
            exit();
        } catch (PDOException $e) {
            // Handle duplicate email error gracefully
            if ($e->getCode() == 23000) {
                $error = 'This email is already registered.';
            } else {
                $error = 'Registration failed: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="../public/styles.css">
    <style>
        /* ...existing code... */
    </style>
</head>
<body>
    <div class="auth-container">
        <h2>Register</h2>
        <?php if (!empty($error)) echo '<p style="color:red;">' . $error . '</p>'; ?>
        <form method="post" action="register.php">
            <label>First Name:
                <input type="text" name="first_name" placeholder="Enter your first name" required>
            </label>
            <label>Last Name:
                <input type="text" name="last_name" placeholder="Enter your last name" required>
            </label>
            <label>Email:
                <input type="email" name="email" placeholder="Enter your email" required>
            </label>
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="../php/signin.html">Sign in</a></p>
    </div>
</body>
</html>
