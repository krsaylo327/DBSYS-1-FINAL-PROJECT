<?php
require_once 'config.php';

// Use PDO from config.php
function getInstructors($pdo) {
    $sql = "SELECT * FROM Instructors";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$instructors = getInstructors($pdo);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructors</title>
    <link rel="stylesheet" href="../public/styles.css">
    <style>
        body {
            background: linear-gradient(120deg, #f6d365 0%, #fda085 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .instructor-container {
            background: #fff;
            padding: 2.5rem 2rem;
            border-radius: 16px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.2);
            width: 600px;
            text-align: center;
        }
        .instructor-container h1 {
            color: #f76b1c;
            margin-bottom: 1.5rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
        }
        th, td {
            padding: 0.7rem 0.5rem;
            border-bottom: 1px solid #eee;
            text-align: left;
        }
        th {
            background: #f6d36544;
            color: #f76b1c;
        }
        tr:last-child td {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="instructor-container">
        <h1>Instructors List</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
            </tr>
            <?php foreach ($instructors as $instructor): ?>
            <tr>
                <td><?php echo htmlspecialchars($instructor['instructor_id']); ?></td>
                <td><?php echo htmlspecialchars($instructor['first_name']); ?></td>
                <td><?php echo htmlspecialchars($instructor['last_name']); ?></td>
                <td><?php echo htmlspecialchars($instructor['email']); ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>