<?php
session_start();
include_once dirname(__DIR__, 2) . '/db_connect.php';

// Function to retrieve all courses
function getCourses($conn) {
    $sql = "SELECT * FROM Courses";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return [];
    }
}

// Function to retrieve course details by course ID
function getCourseDetails($conn, $courseId) {
    $sql = "SELECT * FROM Courses WHERE course_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $courseId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

// Fetch all courses
$courses = getCourses($conn);

// Close the database connection
$conn->close();
?>