<?php
// enrollments.php

session_start();
include_once dirname(__DIR__, 2) . '/db_connect.php';

// Function to get all enrollments
function getEnrollments($conn) {
    $sql = "SELECT e.enrollment_id, 
                   CONCAT(s.first_name, ' ', s.last_name) AS student_name, 
                   c.course_name AS course_title, 
                   e.enrollment_date, 
                   e.grade 
            FROM enrollments e 
            JOIN students s ON e.student_id = s.student_id 
            JOIN courses c ON e.course_id = c.course_id";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to enroll a student in a course
function enrollStudent($conn, $studentId, $courseId, $grade) {
    $stmt = $conn->prepare("INSERT INTO enrollments (student_id, course_id, enrollment_date, grade) VALUES (?, ?, CURRENT_DATE, ?)");
    $stmt->bind_param("iid", $studentId, $courseId, $grade);
    return $stmt->execute();
}

// Function to withdraw a student from a course
function withdrawStudent($conn, $enrollmentId) {
    $stmt = $conn->prepare("DELETE FROM enrollments WHERE enrollment_id = ?");
    $stmt->bind_param("i", $enrollmentId);
    return $stmt->execute();
}

// Function to update enrollment grade
function updateEnrollmentGrade($conn, $enrollmentId, $newGrade) {
    $stmt = $conn->prepare("UPDATE enrollments SET grade = ? WHERE enrollment_id = ?");
    $stmt->bind_param("di", $newGrade, $enrollmentId);
    return $stmt->execute();
}

// Fetch all enrollments
$enrollments = getEnrollments($conn);
$conn->close();
?>