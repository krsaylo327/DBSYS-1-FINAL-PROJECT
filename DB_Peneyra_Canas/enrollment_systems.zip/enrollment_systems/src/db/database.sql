CREATE DATABASE student_enrollment;

USE student_enrollment;

CREATE TABLE Students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    enrollment_date DATE DEFAULT CURRENT_DATE,
    section VARCHAR(2) NOT NULL,
    year INT NOT NULL
);

CREATE TABLE Courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(10) NOT NULL UNIQUE,
    course_name VARCHAR(100) NOT NULL,
    capacity INT NOT NULL CHECK (capacity > 0),
    year INT NOT NULL DEFAULT 1
);

CREATE TABLE Instructors (
    instructor_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT NOT NULL,
    grade DECIMAL(5, 2) CHECK (grade BETWEEN 0 AND 100),
    enrollment_date DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE SET NULL,
    FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insert subjects for 1st to 4th year into the courses table with course codes
INSERT INTO Courses (course_name, year, course_code) VALUES
('Mathematics 1', 1, 'MATH101'),
('English 1', 1, 'ENG101'),
('Introduction to Programming', 1, 'CS101'),
('Mathematics 2', 2, 'MATH201'),
('English 2', 2, 'ENG201'),
('Data Structures', 2, 'CS201'),
('Mathematics 3', 3, 'MATH301'),
('English 3', 3, 'ENG301'),
('Algorithms', 3, 'CS301'),
('Mathematics 4', 4, 'MATH401'),
('English 4', 4, 'ENG401'),
('Capstone Project', 4, 'CS499');

ALTER TABLE Courses ADD COLUMN year INT NOT NULL DEFAULT 1;