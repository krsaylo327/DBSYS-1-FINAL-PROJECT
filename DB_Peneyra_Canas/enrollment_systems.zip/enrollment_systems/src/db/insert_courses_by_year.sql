-- Add a 'year' column to the courses table if it does not exist
ALTER TABLE courses ADD COLUMN year INT;
-- Add a 'course_code' column to the courses table if it does not exist
ALTER TABLE courses ADD COLUMN course_code VARCHAR(20);

-- Insert subjects for 1st to 4th year into the courses table with course codes
INSERT INTO courses (course_name, year, course_code) VALUES
('Mathematics 1', 1, 'MATH101'),
('English 1', 1, 'ENG101'),
('Introduction to Programming', 1, 'CS101'),
('Mathematics 2', 2, 'MATH201'),
('English 2', 2, 'ENG201'),
('Data Structures', 2, 'CS201'),
('Mathematics 3', 3, 'MATH301'),
('English 3', 3, 'ENG301'),
('Algorithms', 3, 'CS301'),
('Mathematics 4', 4, 'MATH401'),
('English 4', 4, 'ENG401'),
('Capstone Project', 4, 'CS499');
