<?php
// subject_enroll.php
include 'db_connect.php';
session_start();

$user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;

if (!$user_id) {
    header('Location: signin.php');
    exit();
}

// Handle subject enrollment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    $course_id = intval($_POST['course_id']);
    // Prevent duplicate enrollment
    $check_sql = "SELECT 1 FROM enrollments WHERE student_id = $user_id AND course_id = $course_id LIMIT 1";
    $check_result = $conn->query($check_sql);
    if ($check_result && $check_result->num_rows > 0) {
        $message = "<div class='alert alert-warning text-center'>You are already enrolled in this subject.</div>";
    } else {
        $sql = "INSERT INTO enrollments (student_id, course_id) VALUES ($user_id, $course_id)";
        if ($conn->query($sql) === TRUE) {
            // Show success and redirect to home after 2 seconds
            echo "<div class='alert alert-success text-center'>You are now enrolled in this subject. Redirecting to home...</div>";
            echo "<script>setTimeout(function(){ window.location.href = 'index.php'; }, 2000);</script>";
            exit();
        } else {
            $message = "<div class='alert alert-danger text-center'>Subject enrollment failed: " . $conn->error . "</div>";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll in Subject</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Enrollment System</a>
        </div>
    </nav>
    <div class="container mt-5">
        <?php if (isset($_GET['enrolled'])): ?>
            <div class="alert alert-success text-center">You are now enrolled! Please select a subject to enroll in.</div>
        <?php endif; ?>
        <?php if (!empty($message)) echo $message; ?>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">Enroll in a Subject</div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label for="course_id" class="form-label">Select Subject</label>
                                <select class="form-select" id="course_id" name="course_id" required>
                                    <option value="">Select subject</option>
                                    <?php
                                    $courses_result = $conn->query("SELECT course_id, course_name FROM courses");
                                    if ($courses_result && $courses_result->num_rows > 0) {
                                        while ($row = $courses_result->fetch_assoc()) {
                                            echo '<option value="' . $row['course_id'] . '">' . htmlspecialchars($row['course_name']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success">Enroll in Subject</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
