<?php
// enroll_student.php
include 'db_connect.php';
session_start();

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : (isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
    $name = isset($_POST['name']) ? $conn->real_escape_string($_POST['name']) : '';
    $email = isset($_POST['email']) ? $conn->real_escape_string($_POST['email']) : '';
    $date_of_birth = isset($_POST['date_of_birth']) ? $conn->real_escape_string($_POST['date_of_birth']) : '';
    $phone_number = isset($_POST['phone_number']) ? $conn->real_escape_string($_POST['phone_number']) : '';
    $section = isset($_POST['section']) ? $conn->real_escape_string($_POST['section']) : '';
    $year = isset($_POST['year']) ? intval($_POST['year']) : 0;
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

    // Check if this user_id is already enrolled
    $check_sql = "SELECT 1 FROM students WHERE student_id = $user_id LIMIT 1";
    $check_result = $conn->query($check_sql);
    if ($check_result && $check_result->num_rows > 0) {
        echo "<div class='alert alert-warning text-center'>You are already enrolled. You cannot enroll again in a different section or year.</div>";
    } elseif ($name && $email && $date_of_birth && $phone_number && $section && $year && $user_id) {
        // Insert into students table
        $sql = "INSERT INTO students (student_id, first_name, last_name, email, enrollment_date, section, year) VALUES ($user_id, '" . $conn->real_escape_string(explode(' ', $name)[0]) . "', '" . $conn->real_escape_string(implode(' ', array_slice(explode(' ', $name), 1))) . "', '$email', CURDATE(), '$section', $year)";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['enrolled_name'] = $name;
            // Automatically enroll in all subjects for the selected year
            $courses_result = $conn->query("SELECT course_id FROM courses WHERE year = $year");
            if ($courses_result && $courses_result->num_rows > 0) {
                while ($row = $courses_result->fetch_assoc()) {
                    $course_id = intval($row['course_id']);
                    $conn->query("INSERT INTO enrollments (student_id, course_id) VALUES ($user_id, $course_id)");
                }
            }
            // Redirect to homepage with congrats message
            header('Location: index.php?enrolled_year=' . $year);
            exit();
        } else {
            echo "<div style='color:red;text-align:center;'>Enrollment failed: " . $conn->error . "</div>";
        }
    } else {
        echo "<div style='color:red;text-align:center;'>All fields are required.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Enrollment - Student Enrollment System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);
            min-height: 100vh;
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 4px 24px 0 rgba(30,64,175,0.08);
        }
        .card-header {
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem;
        }
        .form-label {
            font-weight: 500;
        }
        .btn-primary {
            background: linear-gradient(90deg, #2563eb 0%, #1e40af 100%);
            border: none;
        }
        .btn-primary:hover {
            background: linear-gradient(90deg, #1e40af 0%, #2563eb 100%);
        }
        .card-body {
            padding: 2rem;
        }
        .form-control:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 0.2rem rgba(37,99,235,.15);
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Enrollment System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Students</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="courses.php">Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="enrollments.php">Enrollments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Reports</a>
                    </li>
                </ul>
                <form class="d-flex" action="signout.php" method="post">
                    <button class="btn btn-outline-light" type="submit">Sign Out</button>
                </form>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">Complete Your Enrollment</div>
                    <div class="card-body">
                        <form method="POST" action="enroll_student.php">
                            <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_id); ?>">
                            <div class="mb-3">
                                <label for="name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="date_of_birth" class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone_number" class="form-label">Phone</label>
                                <input type="text" class="form-control" id="phone_number" name="phone_number" required>
                            </div>
                            <div class="mb-3">
                                <label for="section" class="form-label">Section</label>
                                <select class="form-select" id="section" name="section" required>
                                    <option value="">Select section</option>
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="year" class="form-label">Year</label>
                                <select class="form-select" id="year" name="year" required>
                                    <option value="">Select year</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Enroll</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
