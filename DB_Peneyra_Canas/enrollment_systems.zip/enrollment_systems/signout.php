<?php
// signout.php
session_start();
// Destroy session and redirect to signin.php with signedout=1
session_destroy();
header('Location: signin.php?signedout=1');
exit();
?>
