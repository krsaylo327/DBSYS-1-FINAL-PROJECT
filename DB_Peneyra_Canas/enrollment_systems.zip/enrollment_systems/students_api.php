<?php
// students_api.php
header('Content-Type: application/json');
include 'db_connect.php';

// Remove s.id from the SELECT if the students table does not have an id column
$sql = "SELECT s.name, u.email, s.dob, s.enrolled_date FROM students s JOIN users u ON s.user_id = u.id";
$result = $conn->query($sql);
$students = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}
echo json_encode($students);
$conn->close();
?>
