<?php
// signin.php
include 'db_connect.php';
session_start();

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Allow login by username or email
    $sql = "SELECT * FROM users WHERE username = '$username' OR email = '$username' LIMIT 1";
    $result = $conn->query($sql);
    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header('Location: index.php'); // Redirect to homepage after sign-in
            exit();
        } else {
            $errorMsg = "<div class='alert alert-danger text-center'>Invalid password.</div>";
        }
    } else {
        $errorMsg = "<div class='alert alert-danger text-center'>User not found.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%); min-height: 100vh; }
        .card { border-radius: 1rem; box-shadow: 0 4px 24px 0 rgba(30,64,175,0.08); }
        .card-header { border-top-left-radius: 1rem; border-top-right-radius: 1rem; }
        .form-label { font-weight: 500; }
        .btn-primary { background: linear-gradient(90deg, #2563eb 0%, #1e40af 100%); border: none; }
        .btn-primary:hover { background: linear-gradient(90deg, #1e40af 0%, #2563eb 100%); }
        .card-body { padding: 2rem; }
        .form-control:focus { border-color: #2563eb; box-shadow: 0 0 0 0.2rem rgba(37,99,235,.15); }
        .mt-3.text-center a { color: #2563eb; text-decoration: underline; }
        .mt-3.text-center a:hover { color: #1e40af; }
    </style>
</head>
<body>
    <div class="container py-4">
        <h2 class="text-center mb-4">Student Enrollment System</h2>
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white text-center">
                        <h4 class="mb-0">Sign In</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($errorMsg) echo $errorMsg; ?>
                        <?php if (isset($_GET['signedout']) && $_GET['signedout'] == 1): ?>
                            <div class="alert alert-success text-center">You have been signed out.</div>
                        <?php endif; ?>
                        <form action="signin.php" method="post">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username or Email</label>
                                <input type="text" class="form-control" id="username" name="username" required autofocus>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Sign In</button>
                        </form>
                        <div class="mt-3 text-center">
                            <span>Don't have an account? <a href="register.php">Register here</a>.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
