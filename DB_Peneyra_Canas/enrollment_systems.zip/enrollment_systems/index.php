<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
include_once 'db_connect.php';

// Helper: Check if user is signed in
$isSignedIn = isset($_SESSION['user_id']);

// Helper: Show enrolled message if just enrolled
$enrolledMsg = '';
if (isset($_SESSION['enrolled_name'])) {
    $enrolledMsg = '<div class="alert alert-success text-center">Welcome, ' . htmlspecialchars($_SESSION['enrolled_name']) . '! You are now enrolled.</div>';
    unset($_SESSION['enrolled_name']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Enrollment System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Students</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="courses.php">Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="enrollments.php">Enrollments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Reports</a>
                    </li>
                </ul>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <form class="d-flex" action="signout.php" method="post">
                        <button class="btn btn-outline-light" type="submit">Sign Out</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="container mt-5 text-center">
        <?php if (isset($_GET['signedout']) && $_GET['signedout'] == 1): ?>
            <div class="alert alert-success text-center">You have been signed out.</div>
        <?php endif; ?>
        <?php
        if (isset($_GET['enrolled_year'])) {
            $year = intval($_GET['enrolled_year']);
            $year_labels = [1 => '1st Year', 2 => '2nd Year', 3 => '3rd Year', 4 => '4th Year'];
            $label = isset($year_labels[$year]) ? $year_labels[$year] : $year . 'th Year';
            echo '<div class="alert alert-success">You are enrolled in ' . $label . '!<br>Congratulations and good luck!</div>';
        }
        ?>
        <h1 class="mb-4">Welcome to the Student Enrollment System</h1>
        <a href="enroll_student.php" class="btn btn-lg btn-primary mb-4">Enroll Now</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
