<?php
session_start();
include_once 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Enrollment System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Students</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="courses.php">Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="enrollments.php">Enrollments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Reports</a>
                    </li>
                </ul>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <form class="d-flex" action="signout.php" method="post">
                        <button class="btn btn-outline-light" type="submit">Sign Out</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <?php if (isset($_GET['signedout']) && $_GET['signedout'] == 1): ?>
            <div class="alert alert-success text-center">You have been signed out.</div>
        <?php endif; ?>
        <h2 class="mb-4">Student List by Year and Section</h2>
        <?php
        $year_labels = [1 => '1st Year', 2 => '2nd Year', 3 => '3rd Year', 4 => '4th Year'];
        $students_result = $conn->query("SELECT CONCAT(first_name, ' ', last_name) AS name, email, section, year FROM students ORDER BY year ASC, section ASC, first_name ASC, last_name ASC");
        $students_by_year_section = [];
        if ($students_result && $students_result->num_rows > 0) {
            while ($student = $students_result->fetch_assoc()) {
                $year = $student['year'];
                $section = $student['section'];
                $students_by_year_section[$year][$section][] = $student;
            }
            foreach ([1,2,3,4] as $year) {
                if (!isset($students_by_year_section[$year])) continue;
                echo '<div class="card mb-4">';
                echo '<div class="card-header bg-primary text-white">' . $year_labels[$year] . '</div>';
                echo '<div class="card-body">';
                foreach (['A','B','C'] as $section) {
                    if (!isset($students_by_year_section[$year][$section])) continue;
                    echo '<h5 class="mt-3">Section ' . $section . '</h5>';
                    echo '<table class="table table-bordered table-striped text-center align-middle">';
                    echo '<thead><tr><th class="text-center">Name</th><th class="text-center">Email</th></tr></thead><tbody>';
                    foreach ($students_by_year_section[$year][$section] as $student) {
                        echo '<tr>';
                        echo '<td class="text-start">' . htmlspecialchars($student['name']) . '</td>';
                        echo '<td class="text-start">' . htmlspecialchars($student['email']) . '</td>';
                        echo '</tr>';
                    }
                    echo '</tbody></table>';
                }
                echo '</div></div>';
            }
        } else {
            echo '<div class="alert alert-warning">No students found.</div>';
        }
        ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
