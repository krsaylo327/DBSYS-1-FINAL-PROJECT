-- Create the students table with the required columns
CREATE TABLE IF NOT EXISTS students (
    user_id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    dob DATE NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(50),
    enrolled_date DATETIME NOT NULL,
    section VARCHAR(2) NOT NULL,
    year INT NOT NULL
);
