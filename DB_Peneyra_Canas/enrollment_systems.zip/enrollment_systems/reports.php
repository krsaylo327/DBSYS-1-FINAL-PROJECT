<?php
session_start();
include_once 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);
            min-height: 100vh;
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 4px 24px 0 rgba(30,64,175,0.08);
        }
        .card-header {
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem;
        }
        .table {
            background: #fff;
            border-radius: 0.5rem;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Enrollment System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Students</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="courses.php">Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="enrollments.php">Enrollments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reports.php">Reports</a>
                    </li>
                </ul>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <form class="d-flex" action="signout.php" method="post">
                        <button class="btn btn-outline-light" type="submit">Sign Out</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="container py-4">
        <?php if (isset($_GET['signedout']) && $_GET['signedout'] == 1): ?>
            <div class="alert alert-success text-center">You have been signed out.</div>
        <?php endif; ?>
        <div class="row mb-4">
            <div class="col-12 d-flex justify-content-between align-items-center">
                <h3 class="mb-0">Reports</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">Total Students by Year</div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped text-center align-middle mb-0">
                            <thead><tr><th>Year</th><th>Total Students</th></tr></thead>
                            <tbody>
                            <?php
                            $year_labels = [1 => '1st Year', 2 => '2nd Year', 3 => '3rd Year', 4 => '4th Year'];
                            for ($year = 1; $year <= 4; $year++) {
                                $result = $conn->query("SELECT COUNT(*) as total FROM students WHERE year = $year");
                                $count = $result ? $result->fetch_assoc()['total'] : 0;
                                echo '<tr><td>' . $year_labels[$year] . '</td><td>' . $count . '</td></tr>';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">Total Enrollments by Subject</div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped text-center align-middle mb-0">
                            <thead><tr><th>Subject</th><th>Year</th><th>Enrolled Students</th></tr></thead>
                            <tbody>
                            <?php
                            $subjects = $conn->query("SELECT course_name, year, course_id FROM courses ORDER BY year ASC, course_name ASC");
                            if ($subjects && $subjects->num_rows > 0) {
                                while ($subject = $subjects->fetch_assoc()) {
                                    $course_id = $subject['course_id'];
                                    $count_result = $conn->query("SELECT COUNT(*) as total FROM enrollments WHERE course_id = $course_id");
                                    $count = $count_result ? $count_result->fetch_assoc()['total'] : 0;
                                    echo '<tr>';
                                    echo '<td>' . htmlspecialchars($subject['course_name']) . '</td>';
                                    echo '<td>' . htmlspecialchars($subject['year']) . '</td>';
                                    echo '<td>' . $count . '</td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="3">No subjects found.</td></tr>';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
